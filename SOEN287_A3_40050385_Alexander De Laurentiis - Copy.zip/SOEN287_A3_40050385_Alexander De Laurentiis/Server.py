from flask import Flask, render_template, session, request, redirect, flash
import json, sqlite3
import bcrypt

# ========ADMIN LOG IN=============
#User: Zandrenel
#Pass: Pt,Ohs!179

#========Current Generic Log In========
#User: Apples
#Pass: Apple!10

#storing the data from the LORE section of the site has been giving trouble or easily messed up,
#after submission to fix that I plan to replace it with sqlite3, the storage and retrieval from the
#tables is much simpler in comparison

app = Flask(__name__)
app.secret_key='sdfwsfwn132423nkj2n42jkndosih2o9gdfgs'

message=""

# Will be done likely after submission 
# def sortLore():
#     with open('data/Lore.json', 'r') as LoreData:
#         Lore=json.loads(LoreData.read())
#         for key in Lore[lvl1]:
#             for key in Lore[lvl1][lvl2]:
#                 for key in Lore[lvl1][lvl2][lvl3]:
#                     if key 
        

# Main route to HomePage
@app.route('/')
def index():
    with open('data/sideBarLinks.json','r') as sideBar:
        links=json.loads(sideBar.read())
    with open('data/mainSite.json','r') as mainText:
        text=json.loads(mainText.read())
    
    return render_template('Template_base.html',links=links,text=text,message=message)

#Route to the LorePage
@app.route("/Lore",methods=['GET','POST'])
def Lore():
    with open('data/Lore.json','r') as LoreData:
        Lore=json.loads(LoreData.read())
    return render_template('Lore.html',Lore=Lore,message=message)


# If admin, page where you can Edit/Add the inside a tab
@app.route("/Lore/<string:mode>/<string:tabName>/<string:headerName>",methods=['GET','POST'])
def Lore_edit(mode,tabName,headerName):
    if returnUser(session['username'])[3]:
        if mode=='edit':
            with open('data/Lore.json','r') as LoreData:
                Lore=json.loads(LoreData.read())
                header=headerName
                txt=Lore['Lore'][tabName][headerName]['text']
        elif mode=='add':
            header=''
            txt=''
        
        return render_template('Lore.html',TabName=tabName,mode=mode,header=header,txt=txt)
    else:
        message='You do not have Authorization for this feature.'
        return render_template('Lore.html',message=message)

# if Admin will process edit of tab information
@app.route("/Lore/ProcessEdit/<string:TabName>/<string:header>",methods=['POST','GET'])
def EditLore(TabName,header):
    if returnUser(session['username'])[3]:
        HeaderName=request.form['HeaderName']
        DocContent=request.form['Descriptions']
        with open('data/Lore.json','r') as LoreData:
            Lore=json.loads(LoreData.read())
        del Lore['Lore'][TabName][header]
        Lore['Lore'][TabName][HeaderName] = {
                    'text':DocContent
                }
        
               
        with open('data/Lore.json','w') as LoreData:
            json.dump(Lore,LoreData,indent=4)


        message='successfully Edited'
        return redirect('/Lore')
    else:
        message='You do not have Authorization for this feature.'
        return redirect('/Lore')

# if admin will allow edit of a tab name
@app.route("/Lore/edit/<string:TabName>",methods=['POST','GET'])
def EditTab(TabName):
    if returnUser(session['username'])[3]:
        Tabname=request.form['edit'+TabName]
        with open('data/Lore.json','r') as LoreData:
            Lore=json.loads(LoreData.read())
        Lore['Lore'][Tabname] = Lore['Lore'][TabName]
        del Lore['Lore'][TabName]
               
        with open('data/Lore.json','w') as LoreData:
            json.dump(Lore,LoreData,indent=4)

        message='successfully Edited'
        return redirect('/Lore')
    else:
        message='You do not have Authorization for this feature.'
        return redirect('/Lore')

# if admin will add information to inside a tab
@app.route("/Lore/ProcessAdd/<string:TabName>",methods=['POST','GET'])
def AddLore(TabName):
    if returnUser(session['username'])[3]:
        #Tabname=request.form['TabName']
        HeaderName=request.form.get('HeaderName')
        DocContent=request.form.get('Descriptions')
        with open('data/Lore.json','r') as LoreData:
            Lore=json.loads(LoreData.read())
        Lore['Lore'][TabName][HeaderName]={
                    'text':DocContent
                }
        with open('data/Lore.json','w') as LoreData:
            json.dump(Lore,LoreData,indent=4)
        message='successfully Added'
        return redirect('/Lore')
    else:
        message='You do not have Authorization for this feature.'
        return redirect('/Lore')

# if admin will add a tab
@app.route("/Lore/addNewTab",methods=['POST','GET'])
def AddLoreTab():
    if returnUser(session['username'])[3]:
        Tabname=request.form['tabAdd']
        with open('data/Lore.json','r') as LoreData:
            Lore=json.loads(LoreData.read())
        Lore['Lore'][Tabname] ={}
               
        with open('data/Lore.json','w') as LoreData:
            json.dump(Lore,LoreData,indent=4)

        message='successfully Edited'
        return redirect('/Lore')
    else:
        message='You do not have Authorization for this feature.'
        return render_template('Lore.html',message=message)

# if admin will delete info from a tab
@app.route("/Lore/delete/<string:Tabname>/<string:HeaderName>",methods=['POST','GET'])
def deleteLore(Tabname,HeaderName):
    print("got to delete")
    if returnUser(session['username'])[3]:
        with open('data/Lore.json','r') as LoreData:
            Lore=json.loads(LoreData.read())
            print(Lore['Lore'][Tabname][HeaderName])
            del Lore['Lore'][Tabname][HeaderName]
            with open('data/Lore.json','w') as LoreDataDel:
                json.dump(Lore,LoreDataDel,indent=4)
            message='DELETE successful'
    else:
        message='You do not have Authorization for this feature.'
    return redirect('/Lore')

# if admin will delete a tab
@app.route("/Lore/delete/<string:Tabname>",methods=['POST','GET'])
def deleteLoreTab(Tabname):
    print("got to delete Tab")
    if returnUser(session['username'])[3]:
        with open('data/Lore.json','r') as LoreData:
            Lore=json.loads(LoreData.read())
            print(Lore['Lore'][Tabname])
            del Lore['Lore'][Tabname]
            with open('data/Lore.json','w') as LoreDataDel:
                json.dump(Lore,LoreDataDel,indent=4)
            message='DELETE successful'
    else:
        message='You do not have Authorization for this feature.'
    return render_template('Lore.html',Lore=Lore,message=message)

# @app.route("/Lore/<String:AdminUser>/Swap")


# will route to the tools tab
@app.route("/Tools")
def tools():
    with open('data/mainSite.json','r') as mainText:
        text=json.loads(mainText.read())
    return render_template('Tools.html',text=text)

# Will route to the logIn tab
@app.route("/LogIn", methods=['GET'])
def logIn():
    return render_template('LogIn.html')

# Will process the log in, if the user exists, and if after decryting the password the passwords match, the current session will be
# set to this user, if they are an admin the session admin will be set to true.
@app.route("/processLogIn", methods=['POST'])
def processLogIn():
    print('Started')
    _user=request.form['user']
    _pass=request.form['pass']
    if (findUser(_user) and bcrypt.checkpw(_pass.encode('utf-8'),(returnUser(_user))[1].encode('utf-8'))):
        print('users match')
        session['Admin']=returnUser(_user)[3]
        session['username']=_user
        print('Log in Sucess')
        return redirect('/')
    else:
        print('logInFailed')
        return redirect("/LogIn")
        flash("Could not Log In.")

# Will return a boolean of if the user exists
def findUser(_user):
    print('finding User')
    LogData = sqlite3.connect("data/Users.sqlite")
    cursor = LogData.cursor();
    LogData.row_factory = sqlite3.Row
    cursor.execute('SELECT * FROM users WHERE userName=?', (_user,))
    user_ = cursor.fetchone()
    print(user_)
    #print(user_[0])
    LogData.close()
    print('tetsing equality of users')
    if user_:
        print('user true')
        return True
    else:
        print('user false')
        return False

# will return the actual user's data if it exists
def returnUser(_user):
    print('finding User')
    LogData = sqlite3.connect("data/Users.sqlite")
    cursor = LogData.cursor();
    LogData.row_factory = sqlite3.Row
    cursor.execute('SELECT * FROM users WHERE userName=?', (_user,))
    user_ = cursor.fetchone()
    print(user_)
    #print(user_[0])
    #print(user_[1])
    LogData.close()
    print('tetsing equality of users')
    if user_:
        print('user true')
        return user_
    else:
        print('user false')
        return None

# will pop the user Session and admin status
@app.route('/LogOut')
def logOut():
     session.pop('username', None)
     session.pop('Admin',None)
     return redirect('/')




# register template
@app.route("/Register",methods=['POST','GET'])
def Register():
    return render_template('Register.html')

# will process the registration, if they exist  won't register, otherwise if validated will add to the dataBase
@app.route("/processRegistration", methods=['POST'])
def processRegistration():
    _user=request.form['user']
    #_user = findUser(_user)
    LogData = sqlite3.connect("data/Users.sqlite")
    cursor = LogData.cursor();
    cursor.execute("CREATE TABLE IF NOT EXISTS users(userName, password, email, admin, level)")
    LogData.close()

    if not findUser(_user):
        _pass=request.form['pass'].encode()
        salt = bcrypt.gensalt()
        _pass = bcrypt.hashpw(_pass, salt)
        _email=request.form['email']
        LogData = sqlite3.connect("data/Users.sqlite")
        cursor = LogData.cursor();
        #cursor.execute("CREATE TABLE users(userName, password, email, admin, level)")
        if _user == "Zandrenel":
            cursor.execute("INSERT INTO users VALUES(?,?,?,?,?)",(_user,_pass.decode(),_email, True, 10))
        else:
            cursor.execute("INSERT INTO users VALUES(?,?,?,?,?)",(_user,_pass.decode(),_email, False, 1))
        LogData.commit()
        LogData.close()
        flash('Registered successfully.')
        print('User should have been successfullly added.')
        return redirect('/')
    else:
        print('User exists, can\'t register')
        flash("User name Already Exists.")
        return render_template("Register.html")

@app.route("/Contact")
def Contact():
    with open('data/mainSite.json','r') as Main:
        data = json.loads(Main.read())
    return render_template('Contact.html',data=data)

@app.route("/Profile")
def profile():
    if session['username']:
        user=returnUser(session['username'])
        return render_template("Profile.html",user=user)
    else:
        return redirect("/")


if __name__=='__main__':
    app.run(debug=True)
