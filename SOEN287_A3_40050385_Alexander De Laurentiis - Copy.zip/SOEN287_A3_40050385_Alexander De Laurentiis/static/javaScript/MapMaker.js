function DrawMap(){
	let population = document.getElementById("population").value;
	let mapName = document.getElementById("MapName").value;
	let mapSize = document.getElementById("MapSize").value;
	let biome = document.getElementById("Biome").value;
	let boarder = document.getElementById("Boarders").value;


	switch(biome){
		case "Desert":{

			if(boarder=="")

		}break;

	}


}