/*
step one, have a different method called per race of ethnicity of name made

then set up a series of rules with regex per race, then create random strings on a loop,
and do so printing the ones that follow the regex pattern until x of them are printed,
ignore the strings that don't fit.

ex:

funtion orc(){
const template=(orc regex);
let count=0;
do{
	let orc = random string of size;
	if(orc.test(template)){
		count++;
		print orc;

	}
}while(count<10)


}
*/

function orcNames(){
	const templateOrc =/[AG] /;
}